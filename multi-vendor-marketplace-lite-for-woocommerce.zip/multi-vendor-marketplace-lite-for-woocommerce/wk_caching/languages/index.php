<?php
/**
 * Silence is golden.
 *
 * Path: woocommerce3.0-plugins/submodules/wk_caching
 *
 * @package WK_Caching
 */
