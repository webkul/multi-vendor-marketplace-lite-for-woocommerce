<?php
/**
 * Silence is golden.
 *
 * @package Multi-Vendor Marketplace Lite for WooCommerce
 */
